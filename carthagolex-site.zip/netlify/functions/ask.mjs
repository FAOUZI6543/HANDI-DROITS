export default async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ reponse: "Méthode non autorisée" }), { 
      status: 405,
      headers: { "Content-Type": "application/json" }
    });
  }

  try {
    const { question } = await req.json();

    if (!question || question.trim() === "") {
      return new Response(JSON.stringify({ 
        reponse: "Veuillez poser une question valide." 
      }), {
        status: 400,
        headers: { "Content-Type": "application/json" }
      });
    }

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENROUTER_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://carthagolex-site.netlify.app",
        "X-Title": "CarthagoLex Handi-Droits"
      },
      body: JSON.stringify({
        model: "qwen/qwen3.6-plus-preview:online",
        messages: [
          { 
            role: "system", 
            content: `Tu es CarthagoLex, assistant juridique expert en droit du handicap et droit social français. 

Tu réponds UNIQUEMENT en français juridique clair, en citant :
- Les articles précis du CASF (Code de l'action sociale et des familles), CSS (Code de la sécurité sociale), Code du travail
- La jurisprudence récente (CE, Cass., CA) avec dates et numéros
- Les textes réglementaires applicables (décrets, arrêtés, circulaires)

Tu structures tes réponses avec :
1. **Principe légal** (article applicable)
2. **Conditions pratiques** (délais, formulaires, organismes)
3. **Jurisprudence récente** si pertinente
4. **Astuces de dossier** pour les accompagnants

Tu restes factuel, précis, et tu cites toujours tes sources.` 
          },
          { 
            role: "user", 
            content: question 
          }
        ],
        max_tokens: 2000,
        temperature: 0.3
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error("Erreur OpenRouter:", errorData);
      return new Response(JSON.stringify({ 
        reponse: "Erreur de l'API. Vérifiez votre clé OPENROUTER_KEY dans les paramètres Netlify." 
      }), {
        status: 500,
        headers: { "Content-Type": "application/json" }
      });
    }

    const data = await response.json();
    const reponse = data.choices?.[0]?.message?.content || "Erreur de génération de la réponse.";

    return new Response(JSON.stringify({ reponse }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });

  } catch (error) {
    console.error("Erreur fonction:", error);
    return new Response(JSON.stringify({ 
      reponse: "Erreur technique temporaire. Veuillez réessayer dans quelques instants." 
    }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
};
